package com.daolayer;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		UserDAO userdao=new UserDAOImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Add User");
		System.out.println("2. ListUsers");
		System.out.println("Enter Your Choice : ");
        int choice=sc.nextInt();
        sc.nextLine();
        if(choice==1)
        {
        	System.out.println("Enter Username,password,name,email");
        	String username=sc.nextLine();
        	String password=sc.nextLine();
        	String name=sc.nextLine();
        	String email=sc.nextLine();
        	int result=userdao.addUser(username, password, name, email);
        	System.out.println(result>0?"User Added Succesfully":"Failed to AddUser!!");
        }
        else if(choice==2)
        {
        	System.out.println("UserList : ");
        	userdao.getUsers().forEach(System.out::println);
        }
	}

}

package com.daolayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO{

	

	@Override
	public List<String> getUsers() {
		List<String> userList=new ArrayList<>();
		try(Connection con=DBConnection.getConnection())
		{
			String sql="select Username from  dao1";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				userList.add(rs.getString("Username"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return userList;
	}

	@Override
	public int addUser(String username, String password, String name, String email) {
		int rowinserted=0;
		try(Connection con=DBConnection.getConnection())
		{
			String sql="Insert into dao1(Username,password,name,email) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ps.setString(3,name);
			ps.setString(4, email);
			 rowinserted=ps.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return rowinserted;
		
	}

}

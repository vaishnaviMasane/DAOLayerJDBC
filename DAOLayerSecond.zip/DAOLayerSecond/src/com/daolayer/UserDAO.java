package com.daolayer;

import java.util.List;

public interface UserDAO {
int addUser(String username,String password,String name,String email);
List<String> getUsers();
}
